package com.dpreview.auto.tests.enums;

public enum DpreviewLoginResult {

	VERIFICATION_EMAIL;
}
