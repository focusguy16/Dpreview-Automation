package com.dpreview.auto.infra.web;

public enum BrowserType {
	
	FIREFOX,
	CHROME,
	INTERNET_EXPLORER,
	OPERA,
	SAFARI;

}
